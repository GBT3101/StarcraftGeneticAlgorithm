Chaosplugin by MasterofChaos
Version 0.8.7

Features:
* Replay Autosaver
  Saves the last game in Starcraftdir\Maps\Replays\Autoreplay\<Number><Playernames&Races>.rep
* Friend follow
  When you receive the message that one of your friends joined a game
  Press Ctrl+F, and the join game dialog will be shown, with the correct gamename. Friendfollow currently works only with english/german broodwar versions. If you have a different Version, contact me so I can add it.
* Chatsave
  When you are in a battle.net channel and press Ctrl+S the chat is saved in Starcraftdir\Chats\<Date and time>.rep
  Does NOT save chat ingame or in the lobby
* Disable Win-Keys/Capslock
  Disables these keys while Starcraft is running
  Needs to be activated in Config-Dialog
* Allows a different Mousespeed inside Starcraft
* Plays a sound when a player joins the game
* Download Status: Display 101 if the user is at 100%

Betaversion - May still contain bugs
Like every 3rd partytool working together with Starcraft there is a small risk, that blizzard decides to invalidate the users Accounts/CD-Keys.
USE AT YOUR OWN RISK!

If you use the Chaosplugin included in the ICCup-Antihack(ICCup.com), you cannot update the plugin yourself, it will be updated by the ICCup Autoupdate. If you use Chaosplugin with BWLauncher (bwprogrammers.com) or Chaoslauncher you can update yourself.

1. Copy Chaosplugin.bwl into the Launcher directory
2. Start the Launcher
3. Check Chaosplugin on (if not already checked)
4. Configure Chaosplugin to your likeing using the Configure Button (expect you would have never guessed this *g*)
4. Press Launch

Changelog:
0.8e bugfixes
0.8b For Starcraft 1.15.3</li>
0.8 Downloadstatus</li>
0.7 Join Alert</li>
0.6 Mousespeed</li>
0.5 Better Replaynames</li>
0.4c Small bugfix</li>
0.4b Hotkeys only active while starcraft is active Window</li>
0.4 Block Win-Keys/Capslock, autoreplay bugfix</li>
0.3 Support for BWLoader 4 Beta</li>
0.2 Friend follow</li>
0.1 Autosave replays</li>

Translations:
Dutch by Sr18
French by Eti307
Finnish by Puosu
Hungarian by zonbi
Croation by ReiKo
Italian by K)RjT
Polish by piR4te_p4Rn
Portuguese(Br) by Tudazul
Korean by DeLusioN
Russian by Meathook
